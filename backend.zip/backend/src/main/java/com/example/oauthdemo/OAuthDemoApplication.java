package com.example.oauthdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OAuthDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(OAuthDemoApplication.class, args);
        System.out.println("OAuthDemoApplication Application started...");
    }
} 
package jungle.farm;

import jungle.cave.Tiger;
import jungle.cave.WhiteTiger;

public class Mother {
	public static void main(String[] args) {
		Tiger tiger = new Tiger();
		
	}
}

class WhiteTiger extends Tiger //isA
{
	void roar() {
		Tiger tiger = new WhiteTiger();
		System.out.println("defaultA   : "+tiger.defaultA);
		System.out.println("privateB   : "+tiger.privateB);
		System.out.println("protectedC : "+tiger.protectedC);
		System.out.println("publicD    : "+tiger.publicD);
		
	}
	void hunt() {
		System.out.println("defaultA   : "+defaultA);
		System.out.println("privateB   : "+privateB);
		System.out.println("protectedC : "+protectedC); //via extends Tunnel
		System.out.println("publicD    : "+publicD);
		
	}
}

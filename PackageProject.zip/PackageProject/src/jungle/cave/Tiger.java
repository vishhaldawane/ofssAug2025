package jungle.cave;
//  c:\windows\system\jungle
//  /user/jungle

import jungle.farm.WhiteTiger;

//a public class has public default ctor
//a non-public class has a non-public default ctor
public class Tiger {
	          int defaultA   = 100;
	private   int privateB   = 200;
	protected int protectedC = 300;
	public    int publicD    = 400;
	
	void roar() {
		System.out.println("Tiger is roaring...");
	}
	public Tiger() {
		
	}
}


class Lion
{
	void roar() {
		Tiger tiger = new Tiger();
		System.out.println("defaultA   : "+tiger.defaultA);
		System.out.println("privateB   : "+tiger.privateB);
		System.out.println("protectedC : "+tiger.protectedC);
		System.out.println("publicD    : "+tiger.publicD);
		
	}
	
	
}



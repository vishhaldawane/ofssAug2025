package jungle.cave;

public class Bee {

}

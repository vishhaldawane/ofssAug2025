import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
        <a class="navbar-brand" href="#">OAuth Demo</a>
        <div class="navbar-nav">
          <a class="nav-link" routerLink="/login" *ngIf="!isLoggedIn()">Login</a>
          <a class="nav-link" routerLink="/register" *ngIf="!isLoggedIn()">Register</a>
          <a class="nav-link" routerLink="/user" *ngIf="isLoggedIn()">User Page</a>
          <a class="nav-link" routerLink="/admin" *ngIf="isLoggedIn()">Admin Page</a>
          <a class="nav-link" href="#" (click)="logout()" *ngIf="isLoggedIn()">Logout</a>
        </div>
      </div>
    </nav>
    <div class="container mt-4">
      <router-outlet></router-outlet>
    </div>
  `,
  styles: []
})
export class AppComponent {
  isLoggedIn(): boolean {
    return localStorage.getItem('token') !== null;
  }

  logout(): void {
    localStorage.removeItem('token');
    window.location.href = '/login';
  }
} 
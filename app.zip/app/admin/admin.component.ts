import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  template: `
    <div class="card">
      <div class="card-header">Admin Page</div>
      <div class="card-body">
        <h5 class="card-title">Welcome to the Admin Page</h5>
        <p class="card-text">This page is accessible only to users with admin role.</p>
        <button class="btn btn-primary" (click)="testAdminEndpoint()">Test Admin Endpoint</button>
        <div class="mt-3" *ngIf="adminResponse">
          <div class="alert alert-info">{{ adminResponse }}</div>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class AdminComponent implements OnInit {
  adminResponse: string = '';

  constructor(private router: Router) {}

  ngOnInit() {
    if (!localStorage.getItem('token')) {
      this.router.navigate(['/login']);
    }
  }

  testAdminEndpoint() {
    fetch('http://localhost:8080/api/admin', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(response => response.text())
    .then(data => {
      this.adminResponse = data;
    })
    .catch(error => {
      console.error('Error:', error);
      this.adminResponse = 'Error accessing admin endpoint';
    });
  }
} 
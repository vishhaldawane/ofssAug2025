import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  template: `
    <div class="card">
      <div class="card-header">User Page</div>
      <div class="card-body">
        <h5 class="card-title">Welcome to the User Page</h5>
        <p class="card-text">This page is accessible to all authenticated users.</p>
        <button class="btn btn-primary" (click)="testUserEndpoint()">Test User Endpoint</button>
        <div class="mt-3" *ngIf="userResponse">
          <div class="alert alert-info">{{ userResponse }}</div>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class UserComponent implements OnInit {
  userResponse: string = '';

  constructor(private router: Router) {}

  ngOnInit() {
    if (!localStorage.getItem('token')) {
      this.router.navigate(['/login']);
    }
  }

  testUserEndpoint() {
    fetch('http://localhost:8080/api/user', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(response => response.text())
    .then(data => {
      this.userResponse = data;
    })
    .catch(error => {
      console.error('Error:', error);
      this.userResponse = 'Error accessing user endpoint';
    });
  }
} 